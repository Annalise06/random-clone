export const SET_WALLET = "SET_WALLET";
export const SET_TOKEN = "SET_TOKEN";
export const USER_DETAILS = "USER_DETAILS";
export const SET_ADUSER = "SET_ADUSER";
export const SET_DEPOSIT = "SET_DEPOSIT";
export const LOGOUT = "LOGOUT";
